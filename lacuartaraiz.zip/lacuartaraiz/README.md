# La Cuarta Raíz — Sitio web

Sitio estático (HTML + CSS + JS, sin frameworks) listo para publicar en Vercel desde GitHub.

## Estructura

```
index.html        Inicio
catalogo.html     Catálogo con filtros por familia, empaque y búsqueda
producto.html     Ficha técnica (una sola plantilla para todos los productos)
nosotros.html     La marca
blog.html         Lista de notas
articulo.html     Nota individual
contacto.html     Formulario que abre WhatsApp / correo + preguntas frecuentes
404.html          Página no encontrada
css/styles.css    Todos los estilos (paleta y tipografías del manual)
js/data.js        ← TODO el contenido editable: contactos, productos, blog
js/main.js        Animaciones, buscador, catálogo, fichas, formulario
assets/fonts      Plaak y Garalda en .woff2
assets/img        Logos, ícono, sellos (ilustraciones) y favicon
vercel.json       URLs limpias y redirección de los QR
qr-urls.csv       Lista de URLs para generar el QR de cada empaque
```

## Ver el sitio en tu computadora

Las ilustraciones se colorean con máscaras CSS, que el navegador bloquea si abres
el archivo con doble clic. Usa un servidor local desde la carpeta del proyecto:

```
python3 -m http.server 8000
```

y abre http://localhost:8000

## Publicar en Vercel

1. Sube esta carpeta a un repositorio de GitHub.
2. En Vercel: **Add New → Project**, elige el repositorio. Framework: **Other**. Sin comando de build.
3. Cada `git push` vuelve a publicar el sitio.
4. Cuando compres el dominio, agrégalo en **Project → Settings → Domains** y cambia
   `dominio` en `js/data.js` y el dominio en `qr-urls.csv`.

## Códigos QR

Cada empaque apunta a una URL corta:

```
https://TU-DOMINIO/p/<slug>      ej.  https://lacuartaraiz.mx/p/jengibre
```

`vercel.json` la redirige a la ficha y marca la visita como QR (aparece un mensaje de bienvenida).
Genera los QR con las URLs de `qr-urls.csv` **después** de tener el dominio definitivo.
Nunca cambies el `slug` de un producto que ya tenga QR impreso.

## Editar contenido

Todo está en `js/data.js`:

- **CONFIG**: número de WhatsApp (con 52 al inicio), contactos, ciudad.
- **PRODUCTOS**: copia un bloque `{ ... }`, cambia `slug` (sin acentos ni espacios) y los textos.
  `sello` elige la ilustración y `color` su tinta (`hoja`, `elote`, `morado`, `tierra`, `rubor`, `cielo`, `rosado`).
  `nota` es opcional y se muestra como aviso.
- **ARTICULOS**: notas del blog; el `cuerpo` acepta HTML sencillo (`<p>`, `<h2>`, `<strong>`).

## Tipografías

Según el manual de identidad, Plaak y Garalda requieren **licencia web** además de la de escritorio
antes de publicar el sitio. Plaak: https://www.205.tf/plaak · Garalda: https://fonts.adobe.com/fonts/garalda
