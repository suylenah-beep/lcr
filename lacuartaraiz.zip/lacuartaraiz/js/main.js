/* =========================================================
   LA CUARTA RAÍZ — Interacciones y vistas dinámicas
   Requiere js/data.js cargado antes.
   ========================================================= */
(() => {
  "use strict";

  /* ---------- Utilidades ---------- */
  const $  = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const pagina = document.body.dataset.page || "";
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const esc = (t = "") => String(t).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const norm = (t = "") => t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
  const cvar = (n) => `var(--${n})`;
  const familia = (id) => FAMILIAS.find((f) => f.id === id);
  const producto = (slug) => PRODUCTOS.find((p) => p.slug === slug);
  const urlProducto = (slug) => `producto.html?p=${encodeURIComponent(slug)}`;
  const urlArticulo = (slug) => `articulo.html?a=${encodeURIComponent(slug)}`;
  const params = new URLSearchParams(location.search);
  const waLink = (texto = CONFIG.whatsappTexto) => `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(texto)}`;
  const fechaLarga = (iso) => new Date(iso + "T12:00:00").toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" });

  const ICON = {
    flecha: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 12h15M13 6l6 6-6 6"/></svg>',
    flechaIzq: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M20 12H5M11 6l-6 6 6 6"/></svg>',
    wa: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M3.5 20.5l1.3-4.2A8.5 8.5 0 1 1 8 19.4l-4.5 1.1z"/><path d="M9 8.6c.2-.5.5-.6.8-.6h.5c.2 0 .4.1.5.4l.7 1.6c.1.2 0 .5-.1.7l-.5.6c.6 1.2 1.6 2.1 2.8 2.7l.6-.5c.2-.2.5-.2.7-.1l1.6.7c.3.1.4.3.4.5v.5c0 .3-.2.7-.6.9-.6.3-1.4.4-2.3.1a8.3 8.3 0 0 1-5.3-5.3c-.2-.8-.1-1.6.2-2.2z" fill="currentColor" stroke="none"/></svg>',
    compartir: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4"/></svg>',
    imprimir: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M6 9V3h12v6M6 18H4v-7h16v7h-2M7 14h10v7H7z"/></svg>',
    buscar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21"/></svg>'
  };

  /* Sello coloreado (ilustración por máscara) */
  function sello(nombre, color = "hoja", clase = "", estilo = "") {
    const [w, h] = SELLOS[nombre] || [1, 1];
    const src = `assets/img/sellos/${nombre}.webp`;
    return `<span class="sello ${clase}" aria-hidden="true" style="--c:${cvar(color)};-webkit-mask-image:url(${src});mask-image:url(${src});--ar:${w}/${h};${estilo}"></span>`;
  }
  const icono = (clase = "", estilo = "") => `<img class="icono ${clase}" src="assets/img/icono.webp" alt="" width="900" height="619" style="${estilo}" loading="lazy">`;

  /* Tarjeta de producto */
  function tarjeta(p, i = 0) {
    const f = familia(p.familia);
    return `
      <a class="tarjeta" href="${urlProducto(p.slug)}" style="--bg:${cvar(f.bg)};--d:${Math.min(i, 12) * 0.04}s">
        <div class="tarjeta__panel">
          <span class="tarjeta__tag">${esc(p.empaque)}</span>
          ${sello(p.sello, p.color)}
          ${icono("tarjeta__icono")}
        </div>
        <div class="tarjeta__info">
          <span class="tarjeta__nombre">${esc(p.nombre)}</span>
          <span class="tarjeta__meta">${esc(f.corto)} · ${esc(p.presentacion)}</span>
          <span class="tarjeta__flecha">${ICON.flecha.replace('viewBox', 'width="18" height="18" viewBox')}</span>
        </div>
      </a>`;
  }

  function notaHTML(a) {
    return `
      <a class="nota" href="${urlArticulo(a.slug)}" data-reveal>
        <div class="nota__panel" style="--bg:${cvar(a.color)}">${sello(a.sello, a.tinta)}</div>
        <div class="nota__cuerpo">
          <span class="eyebrow">${esc(a.tema)}</span>
          <h3>${esc(a.titulo)}</h3>
          <p>${esc(a.resumen)}</p>
        </div>
        <div class="marco"><span class="grow">${fechaLarga(a.fecha)}</span><span>${a.lectura} min</span></div>
      </a>`;
  }

  /* Búsqueda de productos */
  function buscarProductos(q) {
    const n = norm(q);
    if (!n) return [];
    return PRODUCTOS
      .map((p) => {
        const nombre = norm(p.nombre), extra = norm(`${familia(p.familia).nombre} ${p.sci} ${p.empaque}`);
        let score = -1;
        if (nombre.startsWith(n)) score = 3;
        else if (nombre.split(" ").some((w) => w.startsWith(n))) score = 2;
        else if (nombre.includes(n)) score = 1;
        else if (extra.includes(n)) score = 0;
        return { p, score };
      })
      .filter((r) => r.score >= 0)
      .sort((a, b) => b.score - a.score || a.p.nombre.localeCompare(b.p.nombre, "es"))
      .map((r) => r.p);
  }
  function marcar(texto, q) {
    const n = norm(q), t = norm(texto), i = t.indexOf(n);
    if (!n || i < 0) return esc(texto);
    return esc(texto.slice(0, i)) + "<mark>" + esc(texto.slice(i, i + n.length)) + "</mark>" + esc(texto.slice(i + n.length));
  }
  function resultadoHTML(p, q) {
    const f = familia(p.familia);
    return `<a class="resultado" href="${urlProducto(p.slug)}" role="option">
      <span class="resultado__mini" style="--bg:${cvar(f.bg)}">${sello(p.sello, p.color)}</span>
      <span><span class="resultado__nombre">${marcar(p.nombre, q)}</span><span class="resultado__meta">${esc(f.nombre)} · ${esc(p.presentacion)} · ${esc(p.empaque)}</span></span>
      ${ICON.flecha.replace('viewBox', 'width="20" height="20" viewBox')}
    </a>`;
  }
  /* Conecta un input con una lista de resultados (flechas + enter) */
  function conectarBuscador(input, lista, { vacio = "", alVaciar = null } = {}) {
    let activo = -1;
    const pintar = () => {
      const q = input.value;
      const res = buscarProductos(q);
      activo = -1;
      if (!q.trim()) { lista.innerHTML = alVaciar ? alVaciar() : ""; return; }
      lista.innerHTML = res.length
        ? res.slice(0, 8).map((p) => resultadoHTML(p, q)).join("")
        : `<div class="buscador__vacio"><p class="muted" style="margin:0">No encontramos “${esc(q)}”. ${vacio}</p></div>`;
    };
    input.addEventListener("input", pintar);
    input.addEventListener("keydown", (e) => {
      const items = $$(".resultado", lista);
      if (!items.length) return;
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        activo = (activo + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length;
        items.forEach((it, i) => it.classList.toggle("is-active", i === activo));
        items[activo].scrollIntoView({ block: "nearest" });
      } else if (e.key === "Enter") {
        e.preventDefault();
        (items[activo] || items[0]).click();
      }
    });
    pintar();
    return pintar;
  }

  /* ---------- Componentes globales ---------- */
  function initHeader() {
    const header = $(".header");
    if (!header) return;
    $$(".nav a, .menu__links a").forEach((a) => {
      if (a.dataset.nav === pagina) a.setAttribute("aria-current", "page");
    });
    let ultimo = scrollY, tick = false;
    const wa = $(".wa-flot");
    const actualizar = () => {
      const y = scrollY;
      header.classList.toggle("is-scrolled", y > 8);
      const menuAbierto = $(".menu")?.classList.contains("is-open");
      header.classList.toggle("is-hidden", !menuAbierto && y > 420 && y > ultimo + 2);
      if (y < ultimo - 2) header.classList.remove("is-hidden");
      wa?.classList.toggle("is-visible", y > 380);
      ultimo = y; tick = false;
    };
    addEventListener("scroll", () => { if (!tick) { tick = true; requestAnimationFrame(actualizar); } }, { passive: true });
    actualizar();
  }

  function initMenu() {
    const menu = $(".menu"), abrir = $(".burger"), cerrar = $(".menu .cerrar");
    if (!menu || !abrir) return;
    const set = (on) => {
      menu.classList.toggle("is-open", on);
      menu.setAttribute("aria-hidden", String(!on));
      abrir.setAttribute("aria-expanded", String(on));
      document.documentElement.style.overflow = on ? "hidden" : "";
      if (on) setTimeout(() => cerrar?.focus(), 300); else abrir.focus({ preventScroll: true });
    };
    abrir.addEventListener("click", () => set(true));
    cerrar?.addEventListener("click", () => set(false));
    menu.addEventListener("keydown", (e) => { if (e.key === "Escape") set(false); });
    $$(".menu__links a", menu).forEach((a) => a.addEventListener("click", () => set(false)));
  }

  function initBuscadorGlobal() {
    const caja = $(".buscador");
    if (!caja) return;
    const input = $("input", caja), lista = $(".buscador__res", caja);
    const sugeridos = () => `<div class="buscador__vacio"><p class="eyebrow" style="margin:0 0 10px">Lo más buscado</p></div>` +
      ["epazote", "jengibre", "bok-choy", "hoja-de-platano", "albahaca"].map((s) => resultadoHTML(producto(s), "")).join("");
    conectarBuscador(input, lista, { vacio: "Prueba con otra palabra o revisa el catálogo.", alVaciar: sugeridos });
    let previo = null;
    const set = (on) => {
      caja.classList.toggle("is-open", on);
      caja.setAttribute("aria-hidden", String(!on));
      document.documentElement.style.overflow = on ? "hidden" : "";
      if (on) { previo = document.activeElement; setTimeout(() => input.focus(), 50); }
      else previo?.focus?.({ preventScroll: true });
    };
    $$("[data-buscar]").forEach((b) => b.addEventListener("click", (e) => { e.preventDefault(); set(true); }));
    caja.addEventListener("click", (e) => { if (e.target === caja) set(false); });
    $(".buscador .cerrar")?.addEventListener("click", () => set(false));
    addEventListener("keydown", (e) => {
      if (e.key === "Escape" && caja.classList.contains("is-open")) set(false);
      const escribiendo = /input|textarea|select/i.test(document.activeElement?.tagName || "");
      if (e.key === "/" && !escribiendo) { e.preventDefault(); set(true); }
    });
  }

  function initWhatsApp() {
    $$("[data-wa]").forEach((a) => {
      a.href = waLink(a.dataset.waText || CONFIG.whatsappTexto);
      a.target = "_blank"; a.rel = "noopener";
    });
  }

  let observador;
  function observar(raiz = document) {
    const els = $$("[data-reveal], [data-stamp], .split-line", raiz).filter((e) => !e.classList.contains("is-in"));
    if (reduceMotion || !("IntersectionObserver" in window)) { els.forEach((e) => e.classList.add("is-in")); return; }
    observador ||= new IntersectionObserver((ents) => {
      ents.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("is-in"); observador.unobserve(en.target); } });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.12 });
    els.forEach((e) => observador.observe(e));
  }

  function initContadores() {
    const els = $$("[data-count]");
    if (!els.length) return;
    const correr = (el) => {
      const fin = +el.dataset.count, pre = el.dataset.pre || "", dur = 1400, t0 = performance.now();
      const paso = (t) => {
        const k = Math.min(1, (t - t0) / dur), v = Math.round(fin * (1 - Math.pow(1 - k, 3)));
        el.textContent = pre + v;
        if (k < 1) requestAnimationFrame(paso);
      };
      reduceMotion ? (el.textContent = pre + fin) : requestAnimationFrame(paso);
    };
    const io = new IntersectionObserver((ents) => ents.forEach((en) => { if (en.isIntersecting) { correr(en.target); io.unobserve(en.target); } }), { threshold: 0.6 });
    els.forEach((e) => io.observe(e));
  }

  /* Parallax por scroll y cursor para elementos [data-depth] */
  function initParallax() {
    const piezas = $$("[data-depth]");
    if (!piezas.length || reduceMotion) return;
    let mx = 0, my = 0, tick = false;
    const pintar = () => {
      const vh = innerHeight;
      piezas.forEach((el) => {
        const d = parseFloat(el.dataset.depth) || 0;
        const r = el.parentElement.getBoundingClientRect();
        const centro = (r.top + r.height / 2 - vh / 2) / vh;
        el.style.transform = `translate3d(${mx * d * 26}px, ${my * d * 26 - centro * d * 90}px, 0)`;
      });
      tick = false;
    };
    const pedir = () => { if (!tick) { tick = true; requestAnimationFrame(pintar); } };
    addEventListener("scroll", pedir, { passive: true });
    if (matchMedia("(pointer:fine)").matches) addEventListener("pointermove", (e) => { mx = e.clientX / innerWidth - 0.5; my = e.clientY / innerHeight - 0.5; pedir(); }, { passive: true });
    pintar();
  }

  /* Transición suave entre páginas internas */
  function initTransiciones() {
    if (reduceMotion) return;
    document.addEventListener("click", (e) => {
      const a = e.target.closest("a");
      if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
      const url = new URL(a.href, location.href);
      if (a.target === "_blank" || url.origin !== location.origin || a.hasAttribute("download")) return;
      if (url.pathname === location.pathname && url.search === location.search && url.hash) return;
      e.preventDefault();
      document.body.classList.add("is-leaving");
      setTimeout(() => (location.href = url.href), 260);
    });
    addEventListener("pageshow", () => document.body.classList.remove("is-leaving"));
  }

  function toast(html, ms = 4200) {
    let t = $(".toast");
    if (!t) { t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
    t.innerHTML = `<img src="assets/img/icono.webp" alt="">${html}`;
    requestAnimationFrame(() => t.classList.add("is-on"));
    clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove("is-on"), ms);
  }

  function initMarquesina() {
    $$(".marquesina__pista").forEach((pista) => {
      const nombres = PRODUCTOS.map((p) => p.nombre);
      const bloque = nombres.map((n) => `<span class="marquesina__item">${esc(n)}<img src="assets/img/icono.webp" alt=""></span>`).join("");
      pista.innerHTML = bloque + bloque;
    });
  }

  /* Carrusel arrastrable */
  function initCarrusel(el) {
    if (!el) return;
    const barra = $(".progreso span", el.parentElement);
    const upd = () => { if (barra) { const max = el.scrollWidth - el.clientWidth; const vis = el.clientWidth / el.scrollWidth; barra.style.width = Math.max(vis, max ? (el.scrollLeft + el.clientWidth) / el.scrollWidth : 1) * 100 + "%"; } };
    el.addEventListener("scroll", upd, { passive: true }); addEventListener("resize", upd); upd();
    let x0 = 0, s0 = 0, abajo = false, movio = false;
    el.addEventListener("pointerdown", (e) => { if (e.pointerType !== "mouse") return; abajo = true; movio = false; x0 = e.clientX; s0 = el.scrollLeft; });
    addEventListener("pointermove", (e) => { if (!abajo) return; const dx = e.clientX - x0; if (Math.abs(dx) > 4) { movio = true; el.classList.add("is-drag"); } el.scrollLeft = s0 - dx; });
    addEventListener("pointerup", () => { abajo = false; setTimeout(() => el.classList.remove("is-drag"), 0); });
    el.addEventListener("click", (e) => { if (movio) { e.preventDefault(); movio = false; } }, true);
    $$("[data-carrusel]").forEach((b) => b.addEventListener("click", () => el.scrollBy({ left: (+b.dataset.carrusel) * el.clientWidth * 0.8, behavior: "smooth" })));
  }

  /* ---------- Páginas ---------- */
  const PAGINAS = {
    inicio() {
      const hero = $(".hero");
      requestAnimationFrame(() => setTimeout(() => hero?.classList.add("is-ready"), 120));

      const fam = $("#familias");
      if (fam) fam.innerHTML = FAMILIAS.map((f, i) => {
        const n = PRODUCTOS.filter((p) => p.familia === f.id).length;
        return `<a class="familia" href="catalogo.html?f=${f.id}" style="--bg:${cvar(f.bg)}" data-reveal>
          <span class="familia__num"><span>0${i + 1}</span><span>${n} productos</span></span>
          ${sello(f.sello, f.tinta)}
          <span><span class="familia__nombre">${esc(f.nombre)}</span><span class="familia__ver">Ver familia</span></span>
        </a>`;
      }).join("");
      $$("#familias .familia").forEach((el, i) => el.style.setProperty("--d", `${i * 0.07}s`));

      const dest = $("#destacados");
      if (dest) {
        const lista = ["albahaca", "berenjena", "jengibre", "bok-choy", "hoja-de-platano", "ajo-japones", "esparrago", "epazote", "flor-de-pensamiento", "chilacayota"];
        dest.innerHTML = lista.map(producto).filter(Boolean).map(tarjeta).join("");
        initCarrusel(dest);
      }
      const notas = $("#notas");
      if (notas) notas.innerHTML = ARTICULOS.slice(0, 3).map(notaHTML).join("");

      const qi = $("#qr-input"), ql = $("#qr-lista");
      if (qi && ql) conectarBuscador(qi, ql, { vacio: "Revisa el nombre en tu etiqueta." });

      $$("[data-total]").forEach((e) => (e.dataset.count = PRODUCTOS.length));

      /* barra roja del proceso */
      const proc = $(".proceso");
      if (proc && !reduceMotion) {
        const upd = () => { const r = proc.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (innerHeight * 0.85 - r.top) / (r.height + innerHeight * 0.3))); proc.style.setProperty("--p", p.toFixed(3)); };
        addEventListener("scroll", upd, { passive: true }); upd();
      } else proc?.style.setProperty("--p", 1);
    },

    catalogo() {
      const rej = $("#catalogo"), chips = $("#chips"), q = $("#cat-q"), emp = $("#cat-emp"), conteo = $("#conteo");
      const estado = { f: params.get("f") || "todos", e: params.get("e") || "", q: params.get("q") || "" };
      if (!FAMILIAS.some((f) => f.id === estado.f)) estado.f = "todos";
      q.value = estado.q;

      const empaques = [...new Set(PRODUCTOS.map((p) => p.empaque))];
      emp.innerHTML = `<option value="">Todo empaque</option>` + empaques.map((e) => `<option ${e === estado.e ? "selected" : ""}>${esc(e)}</option>`).join("");

      chips.innerHTML = `<button class="chip" data-f="todos">Todos <span class="muted">${PRODUCTOS.length}</span></button>` +
        FAMILIAS.map((f) => `<button class="chip" data-f="${f.id}"><span class="punto" style="--c:${cvar(f.bg)}"></span>${esc(f.corto)}</button>`).join("");

      const pintar = () => {
        $$(".chip", chips).forEach((c) => c.setAttribute("aria-pressed", String(c.dataset.f === estado.f)));
        let lista = estado.q ? buscarProductos(estado.q) : [...PRODUCTOS];
        if (estado.f !== "todos") lista = lista.filter((p) => p.familia === estado.f);
        if (estado.e) lista = lista.filter((p) => p.empaque === estado.e);

        const fam = familia(estado.f);
        conteo.innerHTML = `<span>${lista.length} ${lista.length === 1 ? "producto" : "productos"}${fam ? " · " + esc(fam.nombre) : ""}</span>` +
          (estado.f !== "todos" || estado.e || estado.q ? `<button class="link-flecha" id="limpiar" style="background:none;border-top:0;border-left:0;border-right:0">Limpiar filtros <span>×</span></button>` : `<span>Sin precios · solo información</span>`);
        $("#limpiar")?.addEventListener("click", () => { estado.f = "todos"; estado.e = ""; estado.q = ""; q.value = ""; emp.value = ""; pintar(); });

        if (!lista.length) {
          rej.innerHTML = `<div class="vacio">${sello("hoja", "tierra")}<h3 class="h3">Sin resultados</h3><p class="muted" style="margin:0">Intenta con otra palabra o quita algún filtro.</p></div>`;
        } else if (estado.f === "todos" && !estado.q && !estado.e) {
          let i = 0;
          rej.innerHTML = FAMILIAS.map((f) => {
            const ps = lista.filter((p) => p.familia === f.id);
            return `<div class="grupo-titulo"><h2 class="h3">${esc(f.nombre)}</h2><span class="eyebrow">${ps.length} productos</span></div>
              <div class="rejilla">${ps.map((p) => tarjeta(p, i++ % 8)).join("")}</div>`;
          }).join("");
        } else {
          rej.innerHTML = `<div class="rejilla">${lista.map(tarjeta).join("")}</div>`;
        }

        const u = new URLSearchParams();
        if (estado.f !== "todos") u.set("f", estado.f);
        if (estado.e) u.set("e", estado.e);
        if (estado.q) u.set("q", estado.q);
        history.replaceState(null, "", location.pathname + (u.toString() ? "?" + u : ""));

        /* Portada cambia de color según la familia */
        const portada = $(".portada");
        if (portada) portada.style.setProperty("--bg", cvar(fam ? fam.bg : "hoja"));
        const titulo = $("#cat-titulo");
        if (titulo) titulo.textContent = fam ? fam.corto : "Catálogo";
      };

      chips.addEventListener("click", (e) => {
        const b = e.target.closest(".chip"); if (!b) return;
        estado.f = b.dataset.f; pintar();
      });
      emp.addEventListener("change", () => { estado.e = emp.value; pintar(); });
      let t; q.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { estado.q = q.value.trim(); pintar(); }, 140); });
      pintar();
    },

    producto() {
      const raiz = $("#ficha");
      let slug = params.get("p");
      if (!slug) { const m = location.pathname.match(/\/p\/([^/?#]+)/); if (m) slug = decodeURIComponent(m[1]); }
      const p = producto(slug);

      if (!p) {
        document.title = "Producto no encontrado · La Cuarta Raíz";
        raiz.innerHTML = `
          <section class="error" style="min-height:70vh">
            <div>
              ${icono("", "width:160px;margin:0 auto 24px")}
              <h1 class="h1">No encontramos<br>este producto</h1>
              <p class="lead" style="margin:18px auto 28px">Puede que el código haya cambiado. Búscalo por nombre o explora el catálogo.</p>
              <div class="hero__cta" style="justify-content:center"><button class="btn" data-buscar>${ICON.buscar} Buscar producto</button><a class="btn btn--ghost" href="catalogo.html">Ver catálogo</a></div>
            </div>
          </section>`;
        $$("[data-buscar]", raiz).forEach((b) => b.addEventListener("click", () => $(".header [data-buscar]")?.click()));
        return;
      }

      const f = familia(p.familia);
      const idx = PRODUCTOS.indexOf(p);
      const prev = PRODUCTOS[(idx - 1 + PRODUCTOS.length) % PRODUCTOS.length];
      const next = PRODUCTOS[(idx + 1) % PRODUCTOS.length];
      let rel = PRODUCTOS.filter((x) => x.familia === p.familia && x !== p);
      if (rel.length < 4) rel = rel.concat(PRODUCTOS.filter((x) => x.familia !== p.familia && x !== p).slice(idx % 10, idx % 10 + 4 - rel.length));
      rel = rel.slice(0, 4);

      document.title = `${p.nombre} · Ficha técnica · La Cuarta Raíz`;
      $('meta[name="description"]')?.setAttribute("content", `${p.nombre}: ${p.resumen}`);
      $('meta[property="og:title"]')?.setAttribute("content", `${p.nombre} · La Cuarta Raíz`);
      $('meta[property="og:description"]')?.setAttribute("content", p.resumen);

      const filas = [
        ["Presentación", p.presentacion],
        ["Empaque", p.empaque],
        ["Familia", f.nombre],
        p.sci ? ["Nombre científico", `<em>${esc(p.sci)}</em>`] : null,
        ["Origen", "Campo mexicano"]
      ].filter(Boolean);

      raiz.innerHTML = `
        <section class="ficha">
          <div class="wrap">
            <nav class="migas" aria-label="Ruta"><a href="index.html">Inicio</a><span>/</span><a href="catalogo.html">Catálogo</a><span>/</span><a href="catalogo.html?f=${f.id}">${esc(f.corto)}</a><span>/</span><span aria-current="page">${esc(p.nombre)}</span></nav>
            <div class="ficha__grid">
              <div class="ficha__panel" style="--bg:${cvar(f.bg)}">
                <div class="marco"><span>Ficha técnica</span><span class="grow">${esc(p.nombre)}</span><span>${String(idx + 1).padStart(2, "0")}/${PRODUCTOS.length}</span></div>
                ${sello(p.sello, "negro", "sombra")}
                <div class="sello-grande" data-depth=".25" style="display:grid">${sello(p.sello, p.color, "", "width:100%;height:100%")}</div>
                <div data-stamp style="--r:9deg;--d:.5s;position:absolute;right:6%;bottom:7%;width:clamp(80px,11vw,130px)">${icono("", "position:static;width:100%")}</div>
              </div>
              <div class="ficha__info">
                <span class="chip" style="align-self:flex-start"><span class="punto" style="--c:${cvar(f.bg)}"></span>${esc(f.nombre)}</span>
                <h1 class="ficha__nombre"><span class="split-line"><span>${esc(p.nombre)}</span></span></h1>
                ${p.sci ? `<p class="ficha__sci" data-reveal style="margin-bottom:0">${esc(p.sci)}</p>` : ""}
                <p class="ficha__resumen" data-reveal style="--d:.1s">${esc(p.resumen)}</p>
                <dl class="tabla" data-reveal style="--d:.18s;margin:0">
                  <div class="tabla__titulo"><span>Datos del producto</span><span>La Cuarta Raíz</span></div>
                  ${filas.map(([k, v]) => `<div class="tabla__fila"><dt>${k}</dt><dd>${v.startsWith("<em>") ? v : esc(v)}</dd></div>`).join("")}
                </dl>
                ${p.nota ? `<div class="aviso" data-reveal role="note">${esc(p.nota)}</div>` : ""}
                <div class="ficha__acciones" data-reveal style="--d:.24s">
                  <button class="btn" id="compartir">${ICON.compartir} Compartir</button>
                  <a class="btn btn--wa" data-wa data-wa-text="¡Hola! Vi la ficha de ${esc(p.nombre)} en su página y me gustaría más información.">${ICON.wa} Preguntar</a>
                  <button class="btn btn--ghost" onclick="window.print()">${ICON.imprimir} Imprimir</button>
                </div>
              </div>
            </div>
            <div class="ficha__secciones">
              <div class="bloque" data-reveal>
                <span class="eyebrow">01 · En la cocina</span>
                <h2>¿Cómo usarlo?</h2>
                <ol>${p.usos.map((u) => `<li>${esc(u)}</li>`).join("")}</ol>
              </div>
              <div class="bloque" data-reveal style="--d:.08s">
                <span class="eyebrow">02 · Conservación</span>
                <h2>Que dure más</h2>
                <p style="margin:0">${esc(p.conservacion)}</p>
                <span class="eyebrow" style="margin-top:10px">Consejo</span>
                <p style="margin:0">${esc(p.tip)}</p>
              </div>
              <div class="bloque bloque--color" data-reveal style="--d:.16s;--bg:${cvar(f.bg)}">
                <span class="eyebrow">03 · Dato de campo</span>
                <h2>¿Sabías que…?</h2>
                <p class="lead" style="margin:0">${esc(p.dato)}</p>
                ${sello(p.sello, p.color, "", "width:90px;height:90px;margin-top:8px")}
              </div>
            </div>
            <nav class="ficha__nav" aria-label="Otros productos">
              <a href="${urlProducto(prev.slug)}"><span class="eyebrow">← Anterior</span><strong>${esc(prev.nombre)}</strong></a>
              <a href="${urlProducto(next.slug)}"><span class="eyebrow">Siguiente →</span><strong>${esc(next.nombre)}</strong></a>
            </nav>
          </div>
        </section>
        <section class="section">
          <div class="wrap">
            <div class="cabecera"><h2 class="h2" data-reveal>También te puede gustar</h2><a class="link-flecha" href="catalogo.html?f=${f.id}">Ver ${esc(f.corto.toLowerCase())} <span>→</span></a></div>
            <div class="rejilla">${rel.map(tarjeta).join("")}</div>
          </div>
        </section>`;

      $("#compartir").addEventListener("click", async () => {
        const url = location.href.replace(/[?&]src=qr/, "");
        try {
          if (navigator.share) await navigator.share({ title: `${p.nombre} · La Cuarta Raíz`, text: p.resumen, url });
          else { await navigator.clipboard.writeText(url); toast("Enlace copiado. ¡Compártelo!"); }
        } catch (_) { /* cancelado */ }
      });

      if (params.get("src") === "qr") setTimeout(() => toast(`<span>¡Gracias por elegir <strong>La Cuarta Raíz</strong>! Esta es la ficha de tu ${esc(p.nombre.toLowerCase())}.</span>`, 5200), 700);
    },

    blog() {
      const cont = $("#blog"), chips = $("#temas");
      const temas = ["Todos", ...new Set(ARTICULOS.map((a) => a.tema))];
      let tema = "Todos";
      chips.innerHTML = temas.map((t) => `<button class="chip" data-t="${esc(t)}">${esc(t)}</button>`).join("");
      const pintar = () => {
        $$(".chip", chips).forEach((c) => c.setAttribute("aria-pressed", String(c.dataset.t === tema)));
        const lista = [...ARTICULOS].sort((a, b) => b.fecha.localeCompare(a.fecha)).filter((a) => tema === "Todos" || a.tema === tema);
        cont.className = "notas" + (tema === "Todos" ? " notas--destacada" : "");
        cont.innerHTML = lista.map(notaHTML).join("");
        observar(cont);
      };
      chips.addEventListener("click", (e) => { const b = e.target.closest(".chip"); if (b) { tema = b.dataset.t; pintar(); } });
      pintar();
    },

    articulo() {
      const raiz = $("#articulo");
      const a = ARTICULOS.find((x) => x.slug === params.get("a"));
      if (!a) { location.replace("blog.html"); return; }
      const orden = [...ARTICULOS].sort((x, y) => y.fecha.localeCompare(x.fecha));
      const sig = orden[(orden.indexOf(a) + 1) % orden.length];
      document.title = `${a.titulo} · Blog · La Cuarta Raíz`;
      $('meta[name="description"]')?.setAttribute("content", a.resumen);

      raiz.innerHTML = `
        <div class="lectura-barra" aria-hidden="true"></div>
        <header class="portada" style="--bg:${cvar(a.color)}">
          <div class="wrap">
            <div class="marco"><span>Blog</span><span class="grow">${esc(a.tema)}</span><span>${fechaLarga(a.fecha)}</span><span>${a.lectura} min</span></div>
            <div class="portada__grid">
              <div>
                <nav class="migas" aria-label="Ruta"><a href="index.html">Inicio</a><span>/</span><a href="blog.html">Blog</a></nav>
                <h1 class="h1" style="max-width:14ch">${esc(a.titulo)}</h1>
                <p class="lead" style="margin-top:20px">${esc(a.resumen)}</p>
              </div>
              <div data-stamp style="--r:-8deg;width:clamp(110px,16vw,220px)">${sello(a.sello, a.tinta, "", "width:100%;aspect-ratio:var(--ar)")}</div>
            </div>
          </div>
        </header>
        <section class="section">
          <div class="wrap"><article class="articulo">${a.cuerpo}</article></div>
        </section>
        <section class="section section--tight" style="border-top:var(--borde)">
          <div class="wrap">
            <div class="cabecera"><h2 class="h2">Productos en esta nota</h2><a class="link-flecha" href="catalogo.html">Catálogo <span>→</span></a></div>
            <div class="rejilla">${a.productos.map(producto).filter(Boolean).map(tarjeta).join("")}</div>
          </div>
        </section>
        <nav class="wrap" style="padding-bottom:clamp(64px,8vw,120px)">
          <a class="nota" href="${urlArticulo(sig.slug)}" style="flex-direction:row;align-items:stretch">
            <div class="nota__cuerpo" style="align-content:center"><span class="eyebrow">Siguiente lectura →</span><h3 class="h3">${esc(sig.titulo)}</h3></div>
            <div class="nota__panel" style="--bg:${cvar(sig.color)};aspect-ratio:auto;width:34%;border-bottom:0;border-left:var(--borde)">${sello(sig.sello, sig.tinta)}</div>
          </a>
        </nav>`;

      const barra = $(".lectura-barra", raiz), art = $(".articulo", raiz);
      const upd = () => { const r = art.getBoundingClientRect(); const p = Math.min(1, Math.max(0, -r.top / (r.height - innerHeight * 0.6))); barra.style.transform = `scaleX(${p})`; };
      addEventListener("scroll", upd, { passive: true }); upd();
    },

    contacto() {
      const form = $("#form-contacto");
      if (!form) return;
      const sel = $("#f-producto");
      sel.innerHTML = `<option value="">Ninguno en particular</option>` + FAMILIAS.map((f) =>
        `<optgroup label="${esc(f.nombre)}">${PRODUCTOS.filter((p) => p.familia === f.id).map((p) => `<option value="${p.slug}">${esc(p.nombre)}</option>`).join("")}</optgroup>`).join("");
      if (params.get("p") && producto(params.get("p"))) sel.value = params.get("p");

      const mensaje = () => {
        const d = new FormData(form);
        const prod = producto(d.get("producto"));
        return [
          `¡Hola, La Cuarta Raíz! Soy ${d.get("nombre") || "—"}.`,
          `Escribo como: ${d.get("tipo")}.`,
          d.get("ciudad") ? `Ciudad: ${d.get("ciudad")}.` : "",
          prod ? `Producto de interés: ${prod.nombre}.` : "",
          "",
          d.get("mensaje") || ""
        ].filter((l, i, arr) => l !== "" || (i > 0 && arr[i - 1] !== "")).join("\n").trim();
      };
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (!form.reportValidity()) return;
        window.open(waLink(mensaje()), "_blank", "noopener");
        toast("Abrimos WhatsApp con tu mensaje listo para enviar.");
      });
      $("#por-correo")?.addEventListener("click", () => {
        if (!form.reportValidity()) return;
        const d = new FormData(form);
        location.href = `mailto:${CONFIG.contactos[0].correo}?subject=${encodeURIComponent("Contacto desde la web · " + (d.get("tipo") || ""))}&body=${encodeURIComponent(mensaje())}`;
      });

      const lista = $("#lista-contactos");
      if (lista) lista.innerHTML = CONFIG.contactos.map((c) => `
        <a class="dato" href="tel:+52${c.tel.replace(/\s/g, "")}"><small>${esc(c.area)} · Teléfono</small><strong>${esc(c.tel)}</strong><span class="muted" style="font-size:1rem">${esc(c.nombre)}</span></a>
        <a class="dato" href="mailto:${esc(c.correo)}"><small>${esc(c.area)} · Correo</small><strong style="font-size:1.25rem">${esc(c.correo)}</strong></a>`).join("");
    },

    nosotros() {
      const g = $("#galeria");
      if (g) {
        const piezas = [["berenjena", "morado", "elote"], ["jengibre", "tierra", "hoja"], ["pakchoi-tallo", "hoja", "rosado"], ["ajo", "elote", "cielo"], ["esparragos", "hoja", "morado"], ["platanoja", "hoja", "elote"]];
        g.innerHTML = piezas.map(([s, c, bg], i) => `<div style="--bg:${cvar(bg)}" data-reveal>${sello(s, c)}</div>`).join("");
        $$("#galeria > div").forEach((el, i) => el.style.setProperty("--d", `${i * 0.07}s`));
      }
    }
  };

  /* ---------- Arranque ---------- */
  function iniciar() {
    $$("[data-anio]").forEach((e) => (e.textContent = new Date().getFullYear()));
    $$("[data-total-txt]").forEach((e) => (e.textContent = PRODUCTOS.length));
    initMarquesina();
    PAGINAS[pagina]?.();
    initHeader();
    initMenu();
    initBuscadorGlobal();
    initWhatsApp();
    initContadores();
    initParallax();
    initTransiciones();
    observar();
  }
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", iniciar) : iniciar();
})();
