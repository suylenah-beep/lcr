/* =========================================================
   LA CUARTA RAÍZ — Datos del sitio
   ---------------------------------------------------------
   Aquí vive TODO el contenido editable:
   1. CONFIG      → teléfonos, correo, dominio
   2. FAMILIAS    → categorías del catálogo
   3. SELLOS      → ilustraciones (no tocar salvo que agregues una)
   4. PRODUCTOS   → fichas técnicas (una por producto / QR)
   5. ARTICULOS   → entradas del blog

   Para agregar un producto copia un bloque { ... } de PRODUCTOS,
   cambia el "slug" (sin acentos ni espacios) y su QR será:
   https://TU-DOMINIO/p/<slug>
   ========================================================= */

const CONFIG = {
  marca: "La Cuarta Raíz",
  lema: "Reforzando los valores del campo para llevarlos a su mesa",
  // Número de WhatsApp con lada de país, sin espacios ni signos (52 = México)
  whatsapp: "525525853865",
  whatsappTexto: "¡Hola, La Cuarta Raíz! Vengo de su página web y quiero más información.",
  contactos: [
    { area: "Ventas y negocios", nombre: "Carlos Alberto López Santiago", tel: "55 2585 3865", correo: "carlosalberto_ls@hotmail.com" },
    { area: "Atención y seguimiento", nombre: "Dulce María Ishel López González", tel: "56 2170 1514", correo: "dulcelopez406@outlook.com" }
  ],
  ciudad: "Ciudad de México, México",
  anios: 25,
  // Cambia por tu dominio cuando lo compres (se usa al compartir)
  dominio: "https://lacuartaraiz.mx"
};

/* bg = color del panel de la tarjeta · tinta = color de texto sobre ese panel */
const FAMILIAS = [
  { id: "hierbas",    nombre: "Hierbas",            corto: "Hierbas",    bg: "cielo",  sello: "hoja",          tinta: "hoja",   desc: "Aromáticas, de olla y de té. Cortadas frescas para la cocina y la infusión de cada día." },
  { id: "hojas",      nombre: "Hojas, flores y brotes", corto: "Hojas y flores", bg: "rosado", sello: "pakchoi-hojas", tinta: "hoja",   desc: "Hojas tiernas, germinados y flores comestibles para dar color y frescura." },
  { id: "hortalizas", nombre: "Hortalizas",         corto: "Hortalizas", bg: "elote",  sello: "berenjena",     tinta: "morado", desc: "Calabazas, chayotes, berenjenas y espárragos: la base de la cocina diaria." },
  { id: "legumbres",  nombre: "Legumbres",          corto: "Legumbres",  bg: "morado", sello: "ajo-3",         tinta: "hoja",   desc: "Chícharos, habas y ejotes, cosechados en su punto para guisar o comer al vapor." },
  { id: "raices",     nombre: "Raíces y bulbos",    corto: "Raíces",     bg: "hoja",   sello: "jengibre",      tinta: "tierra", desc: "Jengibre y ajo: sabor profundo que nace bajo la tierra." }
];

/* Ilustraciones efecto sello: [ancho, alto] para conservar proporción */
const SELLOS = {
  "ajo": [447, 617], "ajo-2": [539, 557], "ajo-3": [706, 537], "ajo-4": [585, 669],
  "berenjena": [363, 720], "berenjena-2": [720, 669], "esparragos": [720, 314],
  "fruta": [720, 674], "hoja": [215, 551], "jengibre": [639, 720], "jengibre-2": [346, 720],
  "pakchoi-hojas": [720, 636], "pakchoi-tallo": [320, 720], "platanoja": [720, 603], "platanoja-2": [720, 631]
};

/* ---------------------------------------------------------
   PRODUCTOS (fuente: Produtos4aRaiz.xlsx)
   sello  → ilustración · color → tinta del sello
   nota   → aviso opcional (se muestra resaltado)
   --------------------------------------------------------- */
const PRODUCTOS = [
  /* ===== HIERBAS · Clamshell 50 g ===== */
  {
    slug: "ajenjo", nombre: "Ajenjo", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Artemisia absinthium", sello: "hoja", color: "hoja",
    resumen: "Hierba de hojas plateadas y sabor muy amargo, presente en la herbolaria tradicional mexicana y en la elaboración de licores y bitters.",
    usos: ["Infusión tradicional, siempre en poca cantidad", "Aromatizante en licores y bitters caseros", "Ramilletes aromáticos para la casa"],
    conservacion: "En refrigeración dentro de su empaque, de 5 a 7 días. También puedes secarla colgando los tallos boca abajo en un lugar ventilado y sin sol.",
    tip: "Elige ramas con hojas firmes y color gris verdoso parejo, sin manchas oscuras.",
    dato: "Su amargor es tan intenso que unas cuantas hojas bastan para perfumar toda una botella.",
    nota: "Uso tradicional. No se recomienda durante el embarazo, la lactancia ni en niños; consulta a un profesional de la salud antes de usarla con fines medicinales."
  },
  {
    slug: "albahaca", nombre: "Albahaca", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Ocimum basilicum", sello: "pakchoi-hojas", color: "hoja",
    resumen: "Hojas tiernas de aroma dulce y fresco. Indispensable en salsas, ensaladas y en cualquier plato con jitomate.",
    usos: ["Pesto, salsas verdes y aderezos", "Ensaladas con jitomate y queso fresco", "Aguas frescas con limón o fresa", "Al final de pastas y pizzas"],
    conservacion: "No la refrigeres muy fría: se oscurece. Guárdala como un ramo, con los tallos en un vaso con agua a temperatura ambiente, de 3 a 5 días.",
    tip: "Corta las hojas con las manos o con un cuchillo bien afilado justo antes de servir para que no se ennegrezcan.",
    dato: "Es pariente cercana de la menta: ambas pertenecen a la familia de las lamiáceas."
  },
  {
    slug: "cola-de-caballo", nombre: "Cola de caballo", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Equisetum sp.", sello: "esparragos", color: "hoja",
    resumen: "Planta de tallos huecos y articulados, muy usada en México para preparar infusiones tradicionales.",
    usos: ["Infusión tradicional", "Combinada con otras hierbas de té", "Decoración natural en arreglos"],
    conservacion: "En refrigeración, de 5 a 7 días. Para secarla, extiéndela sobre papel en un lugar ventilado y a la sombra.",
    tip: "Busca tallos verdes y firmes, sin partes amarillas ni secas.",
    dato: "Es una de las plantas más antiguas del planeta: sus parientes ya existían antes que los dinosaurios.",
    nota: "Uso tradicional. Consulta a un profesional de la salud antes de usarla con fines medicinales."
  },
  {
    slug: "epazote", nombre: "Epazote", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Dysphania ambrosioides", sello: "hoja", color: "morado",
    resumen: "La hierba más mexicana de la olla: aroma intenso que no puede faltar en frijoles, esquites, quesadillas y caldos.",
    usos: ["Frijoles de la olla", "Esquites y elotes", "Quesadillas de flor de calabaza u hongos", "Caldo de piedra, sopa de tortilla y moles de olla"],
    conservacion: "Envuelto en papel absorbente ligeramente húmedo dentro de su empaque, en refrigeración, hasta 7 días.",
    tip: "Agrégalo en los últimos minutos de cocción para conservar su aroma; con dos o tres ramas basta.",
    dato: "Su nombre viene del náhuatl epazotl, que se ha relacionado con su olor tan característico."
  },
  {
    slug: "eucalipto", nombre: "Eucalipto", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Eucalyptus globulus", sello: "pakchoi-hojas", color: "morado",
    resumen: "Hojas de aroma fresco y balsámico, tradicionalmente usadas en vaporizaciones y para aromatizar la casa.",
    usos: ["Vaporizaciones tradicionales", "Aromatizar baños y regaderas (cuelga una rama)", "Arreglos y coronas naturales"],
    conservacion: "Muy resistente: en refrigeración hasta 2 semanas, o seco a la sombra durante meses.",
    tip: "Frota una hoja entre los dedos: si es fresca, su aroma se libera de inmediato.",
    dato: "El vapor de la regadera basta para liberar sus aceites aromáticos.",
    nota: "Uso tradicional y aromático. Su aceite no debe ingerirse; consulta a un profesional de la salud antes de usarlo con fines medicinales, sobre todo en niños."
  },
  {
    slug: "hierbabuena", nombre: "Hierbabuena", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Mentha spicata", sello: "pakchoi-hojas", color: "hoja",
    resumen: "Hojas frescas y mentoladas para tés, aguas frescas y caldos. Un clásico de la cocina mexicana.",
    usos: ["Té caliente después de comer", "Aguas frescas de pepino, limón o piña", "Albóndigas y caldo de res", "Mojitos y bebidas"],
    conservacion: "En refrigeración, envuelta en papel ligeramente húmedo, de 5 a 7 días.",
    tip: "Para tés, machaca ligeramente las hojas antes de verter el agua caliente.",
    dato: "En muchas cocinas mexicanas una ramita en las albóndigas es el ingrediente secreto."
  },
  {
    slug: "manzanilla", nombre: "Manzanilla", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Matricaria chamomilla", sello: "fruta", color: "elote",
    resumen: "Flores pequeñas de centro amarillo y aroma dulce. La infusión de la abuela, fresca del campo.",
    usos: ["Té de manzanilla", "Mezclada con miel y limón", "Infusiones frías", "Aromatizar postres de leche"],
    conservacion: "Fresca en refrigeración, de 4 a 6 días. Se seca muy bien: extiende las flores a la sombra y guárdalas en frasco de vidrio.",
    tip: "Usa una cucharada de flores frescas por taza y deja reposar 5 minutos tapado.",
    dato: "Al secarse concentra su aroma, por eso muchas familias la guardan todo el año.",
    nota: "Uso tradicional. Consulta a un profesional de la salud antes de usarla con fines medicinales."
  },
  {
    slug: "romero", nombre: "Romero", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Salvia rosmarinus", sello: "hoja", color: "hoja",
    resumen: "Ramas de hojas finas con aroma resinoso. Perfecto para carnes, papas al horno y aceites aromatizados.",
    usos: ["Papas y verduras al horno", "Pollo, cerdo y cordero", "Aceite o sal de romero", "Focaccia y panes"],
    conservacion: "En refrigeración hasta 10 días. También se seca muy bien colgado boca abajo.",
    tip: "Para soltar las hojas, sujeta la punta y desliza los dedos hacia abajo por el tallo.",
    dato: "Sus tallos más gruesos pueden usarse como brochetas que aromatizan desde dentro."
  },
  {
    slug: "ruda", nombre: "Ruda", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Ruta graveolens", sello: "ajo-4", color: "hoja",
    resumen: "Planta de aroma fuerte muy presente en la tradición popular mexicana, usada sobre todo en ramilletes y limpias.",
    usos: ["Ramilletes tradicionales", "Planta aromática para la casa", "Usos tradicionales y ceremoniales"],
    conservacion: "En refrigeración, de 5 a 7 días.",
    tip: "Manipúlala con guantes si tienes piel sensible: su savia puede irritar con el sol.",
    dato: "Es tradición tener una rama de ruda en casa o en la entrada de los negocios.",
    nota: "No se recomienda ingerirla, especialmente durante el embarazo. Su savia puede causar irritación en la piel expuesta al sol."
  },
  {
    slug: "salvia", nombre: "Salvia", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Salvia officinalis", sello: "pakchoi-hojas", color: "morado",
    resumen: "Hojas aterciopeladas de sabor cálido y ligeramente amargo. Ideal con mantequilla, pastas y carnes.",
    usos: ["Mantequilla dorada con salvia para pastas", "Rellenos de pavo y pollo", "Hojas fritas crujientes", "Infusiones"],
    conservacion: "En refrigeración, envuelta en papel absorbente, de 7 a 10 días.",
    tip: "Fríe las hojas unos segundos en mantequilla: se vuelven crujientes y pierden amargor.",
    dato: "Su nombre viene del latín salvare, por la fama que tuvo en la antigüedad."
  },
  {
    slug: "te-de-limon", nombre: "Té de limón", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "Cymbopogon citratus", sello: "pakchoi-tallo", color: "hoja",
    resumen: "Hojas largas con aroma cítrico, sin ser limón. Para tés calientes, aguas frescas y cocina del sudeste asiático.",
    usos: ["Té caliente o frío", "Agua fresca con jengibre", "Caldos y currys", "Atole y arroz con leche"],
    conservacion: "En refrigeración hasta 2 semanas. También se puede congelar en trozos.",
    tip: "Dobla o anuda las hojas antes de hervirlas para que suelten más aroma.",
    dato: "También se le conoce como zacate limón o hierba limón."
  },
  {
    slug: "toronjil", nombre: "Toronjil", familia: "hierbas", presentacion: "50 g", empaque: "Clamshell",
    sci: "", sello: "hoja", color: "morado",
    resumen: "Hierba de aroma suave y fresco, muy apreciada en México para preparar tés relajantes por la tarde o noche.",
    usos: ["Té por la tarde o noche", "Mezclas con manzanilla o hierbabuena", "Aguas frescas aromáticas"],
    conservacion: "En refrigeración, envuelto en papel ligeramente húmedo, de 5 a 7 días.",
    tip: "Agrega las hojas al agua apenas retirada del fuego y tapa la taza para no perder su aroma.",
    dato: "En México se conocen varias plantas como toronjil, entre ellas el morado y el blanco.",
    nota: "Uso tradicional. Consulta a un profesional de la salud antes de usarlo con fines medicinales."
  },

  /* ===== HOJAS, FLORES Y BROTES ===== */
  {
    slug: "flor-de-pensamiento", nombre: "Flor de pensamiento", familia: "hojas", presentacion: "100 g", empaque: "Clamshell",
    sci: "Viola × wittrockiana", sello: "ajo-4", color: "morado",
    resumen: "Flor comestible de colores intensos y sabor suave. Convierte cualquier plato en una celebración.",
    usos: ["Decorar pasteles y postres", "Ensaladas de hojas", "Cubitos de hielo con flores", "Canapés y platos de evento"],
    conservacion: "En refrigeración dentro de su empaque cerrado, de 3 a 5 días. Manipula con cuidado.",
    tip: "No las laves bajo el chorro: rocíalas con agua y sécalas con papel justo antes de usarlas.",
    dato: "Su sabor recuerda ligeramente a la lechuga; se comen pétalos y centro."
  },
  {
    slug: "germen-de-arugula", nombre: "Germen de arúgula", familia: "hojas", presentacion: "100 g", empaque: "Clamshell",
    sci: "Eruca vesicaria", sello: "pakchoi-hojas", color: "hoja",
    resumen: "Brotes tiernos con el toque picante de la arúgula, en versión pequeña y delicada.",
    usos: ["Tostadas, tacos y sándwiches", "Encima de pizzas y pastas", "Ensaladas y bowls", "Huevos y aguacate"],
    conservacion: "En refrigeración, de 3 a 5 días. Mantén el empaque cerrado y sin humedad.",
    tip: "Agrégalo al final y en crudo para conservar su textura y su sabor picosito.",
    dato: "Concentra el sabor de la planta adulta en unos cuantos días de crecimiento."
  },
  {
    slug: "germen-de-amaranto", nombre: "Germen de amaranto", familia: "hojas", presentacion: "100 g", empaque: "Clamshell",
    sci: "Amaranthus sp.", sello: "ajo-4", color: "tierra",
    resumen: "Brotes de tallos rojizos y sabor suave, un guiño moderno a uno de los cultivos más antiguos de México.",
    usos: ["Ensaladas y bowls", "Tostadas y tacos", "Decorar cremas y sopas", "Sándwiches"],
    conservacion: "En refrigeración, de 3 a 5 días, en su empaque cerrado.",
    tip: "Su color rojizo luce mucho sobre platos claros: úsalo como toque final.",
    dato: "El amaranto, o huauhtli, se cultiva en México desde tiempos prehispánicos."
  },
  {
    slug: "napa", nombre: "Col napa", familia: "hojas", presentacion: "Por pieza", empaque: "Pieza",
    sci: "Brassica rapa subsp. pekinensis", sello: "pakchoi-tallo", color: "hoja",
    resumen: "Col alargada de hojas onduladas y sabor suave y dulce. Más tierna que la col tradicional.",
    usos: ["Kimchi", "Salteados al wok", "Ensaladas crujientes y tacos de pescado", "Rollitos rellenos y caldos"],
    conservacion: "Envuelta en plástico, en el cajón de verduras, hasta 2 semanas.",
    tip: "Usa las hojas exteriores para cocinar y el corazón, más tierno, en crudo.",
    dato: "También se le conoce como col china o repollo chino."
  },
  {
    slug: "bok-choy", nombre: "Bok choy", familia: "hojas", presentacion: "Por pieza", empaque: "Pieza",
    sci: "Brassica rapa subsp. chinensis", sello: "pakchoi-tallo", color: "hoja",
    resumen: "También llamado pak choi: pencas blancas crujientes y hojas verdes tiernas. Listo en minutos.",
    usos: ["Salteado con ajo y salsa de soya", "Al vapor", "En caldos y ramen", "A la plancha, partido a la mitad"],
    conservacion: "En refrigeración, sin lavar, de 4 a 6 días.",
    tip: "Lávalo bien entre las pencas, donde puede quedar tierra. Cocina primero los tallos y al final las hojas.",
    dato: "Las variedades pequeñas se conocen como baby bok choy y se cocinan enteras."
  },
  {
    slug: "mostaza", nombre: "Hoja de mostaza", familia: "hojas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Brassica juncea", sello: "pakchoi-hojas", color: "hoja",
    resumen: "Hojas grandes de sabor ligeramente picante, que se suaviza al cocinarlas.",
    usos: ["Salteada con ajo", "Caldos y sopas", "Encurtidos", "Mezclada con otras verduras de hoja"],
    conservacion: "En refrigeración, envuelta en papel húmedo, de 3 a 5 días.",
    tip: "Si buscas un sabor más suave, blanquéala 1 minuto en agua hirviendo antes de saltearla.",
    dato: "De la misma planta se obtienen las semillas con las que se hace la mostaza."
  },
  {
    slug: "verdolaga", nombre: "Verdolaga", familia: "hojas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Portulaca oleracea", sello: "hoja", color: "hoja",
    resumen: "Quelite de hojas carnosas y sabor ligeramente ácido. Un tesoro de la cocina mexicana tradicional.",
    usos: ["Verdolagas en salsa verde con carne de cerdo", "Con huevo", "Ensaladas frescas", "Quesadillas"],
    conservacion: "En refrigeración, de 3 a 5 días. Lávala justo antes de usarla.",
    tip: "Usa hojas y tallos tiernos; descarta los tallos gruesos y duros.",
    dato: "Es uno de los quelites más conocidos de México, junto con los quintoniles y el huauzontle."
  },
  {
    slug: "sabila", nombre: "Sábila", familia: "hojas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Aloe vera", sello: "hoja", color: "hoja",
    resumen: "Pencas carnosas con un gel transparente en su interior, muy usado en licuados y aguas frescas.",
    usos: ["Licuados verdes", "Aguas frescas", "Cuidado tradicional de la piel (uso externo)"],
    conservacion: "Pencas enteras en refrigeración, hasta 2 semanas. El gel extraído, en frasco cerrado, de 3 a 5 días.",
    tip: "Corta los bordes con espinas, retira la cáscara y enjuaga muy bien el gel para quitar el líquido amarillo.",
    dato: "Una sola penca grande rinde varias tazas de gel.",
    nota: "Retira siempre el líquido amarillo (látex) que está bajo la cáscara: puede tener efecto laxante. No se recomienda su consumo durante el embarazo."
  },
  {
    slug: "azafran", nombre: "Flor de azafrán", familia: "hojas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Crocus sativus", sello: "ajo-4", color: "morado",
    resumen: "La flor morada de la que se obtiene el azafrán: sus estigmas rojos son una de las especias más valiosas del mundo.",
    usos: ["Paella y arroces", "Caldos y cremas", "Postres de leche", "Decoración de platos"],
    conservacion: "Flor fresca en refrigeración, de 2 a 3 días. Los estigmas se secan para conservarlos por mucho tiempo.",
    tip: "Separa los estigmas rojos con cuidado y sécalos a temperatura baja; remójalos en agua tibia antes de usarlos.",
    dato: "Cada flor tiene solo tres estigmas, por eso se necesitan muchas flores para reunir un poco de especia."
  },
  {
    slug: "hoja-de-platano", nombre: "Hoja de plátano", familia: "hojas", presentacion: "Charola 20 × 30 cm", empaque: "Charola",
    sci: "Musa sp.", sello: "platanoja", color: "hoja",
    resumen: "Hojas limpias y cortadas a medida, listas para envolver. Aroma y sabor que solo da el sureste.",
    usos: ["Tamales oaxaqueños y yucatecos", "Cochinita pibil", "Pescado y pollo envueltos", "Base para servir"],
    conservacion: "En refrigeración, bien envueltas, hasta 1 semana. Se pueden congelar.",
    tip: "Pásalas unos segundos por el fuego directo o el comal: se vuelven flexibles y no se rompen al doblar.",
    dato: "Además de envolver, la hoja aporta un aroma ligeramente herbal a lo que cocina."
  },

  /* ===== HORTALIZAS ===== */
  {
    slug: "coles-de-bruselas", nombre: "Coles de Bruselas", familia: "hortalizas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Brassica oleracea var. gemmifera", sello: "fruta", color: "hoja",
    resumen: "Pequeñas coles compactas que se vuelven dulces y doradas al hornearlas o asarlas.",
    usos: ["Al horno con aceite de oliva y sal", "Salteadas con tocino", "Laminadas en crudo para ensalada", "Glaseadas con miel"],
    conservacion: "En refrigeración, en bolsa perforada, de 1 a 2 semanas.",
    tip: "Pártelas a la mitad y ásalas con el lado cortado hacia abajo para que se caramelicen.",
    dato: "Crecen pegadas a lo largo de un tallo alto, como pequeñas cuentas."
  },
  {
    slug: "esparrago", nombre: "Espárrago", familia: "hortalizas", presentacion: "Bolsa", empaque: "Bolsa stand up",
    sci: "Asparagus officinalis", sello: "esparragos", color: "hoja",
    resumen: "Tallos tiernos y crujientes, listos en pocos minutos. Elegantes y muy fáciles de cocinar.",
    usos: ["A la plancha con limón y sal", "Al vapor con mantequilla", "En risottos y pastas", "Envueltos en jamón serrano"],
    conservacion: "De pie en un vaso con un poco de agua dentro del refrigerador, cubiertos con una bolsa, de 3 a 5 días.",
    tip: "Dobla el tallo: se romperá justo donde termina la parte dura.",
    dato: "Las puntas son la parte más tierna y la que se cocina más rápido."
  },
  {
    slug: "berenjena", nombre: "Berenjena", familia: "hortalizas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Solanum melongena", sello: "berenjena", color: "morado",
    resumen: "Piel brillante y pulpa cremosa que absorbe los sabores. Ideal asada, rellena o en guisos.",
    usos: ["Asada al carbón para dips", "Rellena y gratinada", "En capas tipo lasaña", "Guisos y currys"],
    conservacion: "En un lugar fresco o en el cajón del refrigerador, de 4 a 7 días. Es sensible al frío extremo.",
    tip: "Elige piezas firmes, pesadas y de piel tersa; si al presionar regresa, está en su punto.",
    dato: "Botánicamente es un fruto, pariente del jitomate y del chile."
  },
  {
    slug: "calabaza-larga", nombre: "Calabaza larga", familia: "hortalizas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "", sello: "berenjena", color: "hoja",
    resumen: "Calabaza alargada de pulpa suave, perfecta para guisos, sopas y salteados de todos los días.",
    usos: ["Calabacitas a la mexicana", "Sopas y cremas", "Rellenas y gratinadas", "Asadas a la plancha"],
    conservacion: "En refrigeración, en el cajón de verduras, de 5 a 7 días.",
    tip: "Las piezas firmes y de piel brillante tienen mejor textura y menos semillas.",
    dato: "Las calabazas son parte de la milpa mexicana, junto con el maíz y el frijol."
  },
  {
    slug: "calabaza-redonda", nombre: "Calabaza redonda", familia: "hortalizas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "", sello: "fruta", color: "hoja",
    resumen: "Calabaza de forma redonda, ideal para rellenar y servir como plato.",
    usos: ["Rellena de carne o queso", "Al horno", "En caldos", "Cremas"],
    conservacion: "En refrigeración, de 5 a 7 días.",
    tip: "Corta la parte superior como tapa, vacía con cuchara y rellena.",
    dato: "Su forma la hace perfecta como recipiente comestible."
  },
  {
    slug: "chayote-espina", nombre: "Chayote con espina", familia: "hortalizas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Sechium edule", sello: "ajo-2", color: "hoja",
    resumen: "Chayote de piel con espinas suaves y sabor más intenso. Tradicional en caldos y guisos.",
    usos: ["Caldo de res y de pollo", "Chayotes rellenos", "Guisados con jitomate", "Al vapor con mantequilla"],
    conservacion: "En un lugar fresco o en refrigeración, de 1 a 2 semanas.",
    tip: "Pélalo con guantes o bajo el chorro de agua: suelta una savia pegajosa.",
    dato: "El chayote es originario de Mesoamérica; su nombre viene del náhuatl chayohtli."
  },
  {
    slug: "chayote-papa", nombre: "Chayote papa", familia: "hortalizas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Sechium edule", sello: "ajo-3", color: "hoja",
    resumen: "Variedad de chayote de piel lisa y textura firme, que recuerda a la de una papa al cocinarse.",
    usos: ["Caldos y sopas", "Ensalada de chayote", "Salteado", "Puré"],
    conservacion: "En un lugar fresco o en refrigeración, de 1 a 2 semanas.",
    tip: "Cuécelo con todo y cáscara y pélalo ya cocido: es mucho más fácil.",
    dato: "Su textura firme lo hace ideal para platos donde se busca que no se deshaga."
  },
  {
    slug: "chilacayota", nombre: "Chilacayota", familia: "hortalizas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Cucurbita ficifolia", sello: "berenjena-2", color: "hoja",
    resumen: "Calabaza tradicional mexicana de pulpa blanca y fibrosa, protagonista del agua y el dulce de chilacayota.",
    usos: ["Agua de chilacayota con piloncillo", "Dulce en piloncillo", "Guisos con carne", "Caldos"],
    conservacion: "Entera, en un lugar fresco y seco, durante varias semanas. Ya partida, en refrigeración de 3 a 5 días.",
    tip: "Para el agua, cuece la pulpa con piloncillo y canela y deshebra las fibras con un tenedor.",
    dato: "Su piel jaspeada de verde y blanco la hace inconfundible en el mercado."
  },
  {
    slug: "pepino-amargo", nombre: "Pepino amargo", familia: "hortalizas", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Momordica charantia", sello: "berenjena", color: "hoja",
    resumen: "Hortaliza de piel rugosa y sabor amargo característico, muy apreciada en la cocina asiática.",
    usos: ["Salteado con huevo", "Relleno de carne", "En caldos", "Encurtido"],
    conservacion: "En refrigeración, de 3 a 5 días. Madura rápido: úsalo pronto.",
    tip: "Para suavizar el amargor, retira las semillas y la parte blanca, sala las rebanadas 10 minutos y enjuágalas.",
    dato: "También se le conoce como melón amargo o cundeamor chino."
  },

  /* ===== LEGUMBRES ===== */
  {
    slug: "chicharo-cambray", nombre: "Chícharo cambray", familia: "legumbres", presentacion: "100 g", empaque: "Clamshell",
    sci: "Pisum sativum", sello: "hoja", color: "hoja",
    resumen: "Chícharo pequeño y tierno, de sabor dulce. Listo para platos delicados.",
    usos: ["Al vapor con mantequilla", "Arroces y risottos", "Ensaladas frescas", "Cremas de chícharo"],
    conservacion: "En refrigeración, en su empaque, de 3 a 5 días.",
    tip: "Cocínalo pocos minutos: así conserva su color verde brillante y su dulzor.",
    dato: "Cambray se usa en México para nombrar a los productos pequeños y tiernos."
  },
  {
    slug: "chicharo", nombre: "Chícharo", familia: "legumbres", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Pisum sativum", sello: "hoja", color: "elote",
    resumen: "Chícharo en vaina, fresco del campo. Desgránalo y llévalo directo a la olla.",
    usos: ["Arroz rojo o blanco", "Sopa de fideo y caldos", "Picadillo y tortitas", "Ensalada rusa"],
    conservacion: "En vaina, en refrigeración, de 3 a 5 días. Desgranado, se congela muy bien.",
    tip: "Elige vainas verdes, lisas y llenas; si truenan al doblarlas, están frescas.",
    dato: "Desgranar chícharos en familia es de las tareas de cocina más antiguas."
  },
  {
    slug: "ejote-chino", nombre: "Ejote chino", familia: "legumbres", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Vigna unguiculata subsp. sesquipedalis", sello: "esparragos", color: "hoja",
    resumen: "Ejote extra largo, delgado y crujiente. Mantiene su textura incluso salteado a fuego alto.",
    usos: ["Salteado con ajo y chile", "Con huevo", "En caldos y guisos", "Tempura"],
    conservacion: "En refrigeración, en bolsa, de 4 a 6 días.",
    tip: "Córtalo en trozos de 5 cm; no necesita desvenarse.",
    dato: "Puede medir más de 40 cm de largo."
  },
  {
    slug: "haba", nombre: "Haba verde", familia: "legumbres", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Vicia faba", sello: "ajo-3", color: "hoja",
    resumen: "Haba fresca en vaina, de sabor mantequilloso. Temporada de sopas y guisos de cuaresma.",
    usos: ["Sopa de haba", "Habas guisadas con nopales", "Puré con aceite de oliva", "Ensaladas"],
    conservacion: "En vaina, en refrigeración, de 4 a 6 días. Desgranadas y blanqueadas se congelan.",
    tip: "Blanquéalas 1 minuto y retira la piel delgada que las cubre: quedarán más tiernas y verdes.",
    dato: "Es una de las legumbres más antiguas que se cultivan.",
    nota: "Algunas personas con deficiencia de la enzima G6PD no deben consumir habas."
  },

  /* ===== RAÍCES Y BULBOS ===== */
  {
    slug: "ajo-japones", nombre: "Ajo japonés", familia: "raices", presentacion: "50 g", empaque: "Bolsa stand up",
    sci: "Allium sativum", sello: "ajo", color: "elote",
    resumen: "Ajo de sabor intenso y aromático, en presentación práctica para la cocina de todos los días.",
    usos: ["Sofritos y salsas", "Salteados de verduras", "Mojo de ajo", "Aceites aromatizados"],
    conservacion: "En un lugar fresco, seco y ventilado, fuera del refrigerador, varias semanas.",
    tip: "Machácalo con el plano del cuchillo: se pela solo y suelta más sabor.",
    dato: "Picado y reposado unos minutos antes de cocinarlo, desarrolla más aroma."
  },
  {
    slug: "jengibre", nombre: "Jengibre", familia: "raices", presentacion: "1 kg", empaque: "Por kilo",
    sci: "Zingiber officinale", sello: "jengibre", color: "tierra",
    resumen: "Rizoma de sabor picante y fresco. Da vida a tés, aguas, marinados y salteados.",
    usos: ["Té de jengibre con limón y miel", "Agua fresca con piña o limón", "Marinados y salteados", "Galletas y postres"],
    conservacion: "Entero, en refrigeración dentro de una bolsa, hasta 3 semanas. También se puede congelar y rallar congelado.",
    tip: "Pélalo raspando con el borde de una cuchara: quitas solo la piel y no desperdicias.",
    dato: "Lo que comemos no es la raíz, sino un tallo subterráneo llamado rizoma."
  }
];

/* ---------------------------------------------------------
   BLOG
   --------------------------------------------------------- */
const ARTICULOS = [
  {
    slug: "como-conservar-hierbas-frescas",
    titulo: "Cómo conservar tus hierbas frescas por más días",
    fecha: "2026-10-02", tema: "Conservación", color: "cielo", sello: "pakchoi-hojas", tinta: "hoja", lectura: 4,
    resumen: "No todas las hierbas se guardan igual. Te contamos qué hacer con cada una para que duren más.",
    productos: ["albahaca", "hierbabuena", "romero", "epazote"],
    cuerpo: `
<p>Las hierbas frescas cambian por completo un platillo, pero también son de lo más delicado del refrigerador. La buena noticia es que con dos o tres trucos pueden durarte mucho más.</p>
<h2>Hierbas suaves: como un ramo de flores</h2>
<p>La <strong>albahaca</strong> no tolera el frío intenso: se ennegrece. Lo mejor es tratarla como un ramo, con los tallos en un vaso con agua, a temperatura ambiente y lejos del sol directo. Cambia el agua cada dos días.</p>
<h2>Hierbas de hoja: papel húmedo y refrigerador</h2>
<p>La <strong>hierbabuena</strong>, el <strong>epazote</strong> y el <strong>toronjil</strong> se conservan mejor envueltos en papel absorbente ligeramente húmedo, dentro de su empaque o de una bolsa, en el cajón de verduras.</p>
<h2>Hierbas leñosas: las más resistentes</h2>
<p>El <strong>romero</strong> y la <strong>salvia</strong> aguantan hasta diez días en refrigeración. Y si te sobran, se secan muy bien: cuelga los ramos boca abajo en un lugar ventilado y a la sombra.</p>
<h2>¿Y si ya no las voy a usar?</h2>
<p>Pica las hierbas, colócalas en una charola para hielo, cúbrelas con aceite de oliva y congélalas. Tendrás cubitos listos para sofritos, sopas y salsas.</p>
<p>Recuerda: en la ficha de cada producto, a la que llegas escaneando el QR de tu empaque, encontrarás la forma recomendada de conservarlo.</p>`
  },
  {
    slug: "verduras-asiaticas-cocina-mexicana",
    titulo: "Bok choy, napa y ejote chino en la cocina mexicana",
    fecha: "2026-09-24", tema: "Recetas", color: "hoja", sello: "pakchoi-tallo", tinta: "tierra", lectura: 5,
    resumen: "Tres verduras de origen asiático que combinan increíble con los sabores que ya conoces.",
    productos: ["bok-choy", "napa", "ejote-chino", "jengibre"],
    cuerpo: `
<p>Cada vez es más fácil encontrar en el súper verduras que antes solo veíamos en restaurantes. Y aunque vienen de lejos, se llevan muy bien con la cocina de casa.</p>
<h2>Bok choy con salsa macha</h2>
<p>Parte el <strong>bok choy</strong> a la mitad, lávalo bien entre las pencas y ásalo en un sartén muy caliente con un poco de aceite, primero del lado cortado. Termina con unas gotas de limón y una cucharada de salsa macha.</p>
<h2>Tacos de pescado con col napa</h2>
<p>La <strong>col napa</strong> es más tierna y dulce que la col tradicional. Rebánala muy fina, mézclala con limón, sal y cilantro, y úsala como base crujiente para tus tacos de pescado o camarón.</p>
<h2>Ejote chino salteado con chile de árbol</h2>
<p>Corta el <strong>ejote chino</strong> en trozos de cinco centímetros y saltéalo a fuego alto con ajo, chile de árbol y una pizca de sal. Queda crujiente y lleno de sabor en menos de diez minutos.</p>
<p>¿El toque final? Un poco de <strong>jengibre</strong> rallado combina con las tres.</p>`
  },
  {
    slug: "hoja-de-platano-guia",
    titulo: "Hoja de plátano: cómo prepararla para que no se rompa",
    fecha: "2026-09-15", tema: "Técnicas", color: "elote", sello: "platanoja", tinta: "hoja", lectura: 3,
    resumen: "El secreto de los tamales del sureste y de la cochinita está en cómo tratas la hoja antes de envolver.",
    productos: ["hoja-de-platano", "epazote"],
    cuerpo: `
<p>La <strong>hoja de plátano</strong> no solo envuelve: también perfuma. Pero si la doblas en frío, lo más probable es que se rompa. Este es el paso a paso.</p>
<h2>1. Límpiala</h2>
<p>Pasa un trapo húmedo por ambos lados para retirar cualquier residuo.</p>
<h2>2. Suavízala con calor</h2>
<p>Pásala unos segundos por la flama de la estufa o sobre el comal caliente. Verás que cambia a un verde más brillante y se vuelve flexible. Ese es el momento justo.</p>
<h2>3. Envuelve con la veta</h2>
<p>Dobla siempre siguiendo la dirección de las líneas de la hoja; si doblas en contra, se agrieta.</p>
<h2>4. Amarra</h2>
<p>Usa tiras delgadas de la misma hoja como cordel para cerrar tamales o paquetes de pescado.</p>
<p>Nuestras hojas vienen cortadas a 20 × 30 cm en charola, listas para usarse.</p>`
  },
  {
    slug: "tes-de-la-tarde",
    titulo: "Cinco hierbas para el té de la tarde",
    fecha: "2026-09-05", tema: "Bebidas", color: "morado", sello: "hoja", tinta: "hoja", lectura: 3,
    resumen: "Manzanilla, hierbabuena, té de limón y más: cómo preparar cada una con hierba fresca.",
    productos: ["manzanilla", "hierbabuena", "te-de-limon", "toronjil", "jengibre"],
    cuerpo: `
<p>El té con hierba fresca tiene un aroma que no se compara con el de sobre. Estas son cinco combinaciones para la tarde.</p>
<h2>Manzanilla con miel</h2>
<p>Una cucharada de flores de <strong>manzanilla</strong> por taza, agua recién hervida y cinco minutos de reposo, tapado.</p>
<h2>Hierbabuena después de comer</h2>
<p>Machaca ligeramente unas hojas de <strong>hierbabuena</strong> para liberar su aroma antes de agregar el agua.</p>
<h2>Té de limón con jengibre</h2>
<p>Hierve dos hojas de <strong>té de limón</strong> anudadas con tres rodajas de <strong>jengibre</strong> durante cinco minutos.</p>
<h2>Toronjil de la noche</h2>
<p>Agrega las hojas de <strong>toronjil</strong> al agua apenas retirada del fuego y tapa la taza.</p>
<h2>Mezcla de la casa</h2>
<p>Combina hierbabuena, manzanilla y una tira de té de limón. Sírvela caliente o déjala enfriar con hielo.</p>
<p class="aside">Estas son preparaciones de uso cotidiano. Si buscas un uso medicinal, consulta a un profesional de la salud.</p>`
  }
];
